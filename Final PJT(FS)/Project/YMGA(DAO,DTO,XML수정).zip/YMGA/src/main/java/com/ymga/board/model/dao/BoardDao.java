package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Board;

public interface BoardDao {
	
	List<Board> selectAllBoard(String boardType);
	
	void insertBoard(Board board);
	
	void updateBoard(Board board);
	
	void deleteBoard(int id);
	
	Board selectBoardById(int id);

}
