package com.ymga.user.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ymga.user.model.dao.UserZzimVideoDao;
import com.ymga.user.model.dto.UserZzimVideo;

@Service
public class UserZzimVideoServiceImpl implements UserZzimVideoService{

	@Autowired
	private UserZzimVideoDao userZzimVideoDao;
	
	@Override
	public List<UserZzimVideo> selectAllUserZzimVideo(int userSeq) {
		return userZzimVideoDao.selectAllUserZzimVideo(userSeq);
	}

	@Override
	public void registerUserZzimVideo(UserZzimVideo userZzimVideo) {
		userZzimVideoDao.insertUserZzimVideo(userZzimVideo);
	}

	@Override
	public void updateUserZzimVideo(UserZzimVideo userZzimVideo) {
		userZzimVideoDao.updateUserZzimVideo(userZzimVideo);
	}

	@Override
	public void deleteUserZzimVideo(int id) {
		userZzimVideoDao.deleteUserZzimVideo(id);
	}

	@Override
	public UserZzimVideo selectUserZzimVideoById(int id) {
		return userZzimVideoDao.selectUserZzimVideoById(id);
	}

}
