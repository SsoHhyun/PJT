package com.ymga.board.model.service;

import java.util.List;

import com.ymga.board.model.dto.Board;

public interface BoardService {
		
	// 보드 전체 가져오기 (보드 타입 확인)
	List<Board> selectAllBoard(String boardType);
	
	// 보드에 글 등록하기
	void registerBoard(Board board);
	
	// 보드에 글 수정하기
	void updateBoard(Board board);
	
	// 보드에 글 삭제하기
	void deleteBoard(int id);
	
	// 글 하나 읽기(조회수 증가)
	Board readBoardById(int id);
	
	// 글 하나 가져오기
	Board selectBoardById(int id);
	
}