package com.ymga.board.controller;

public class BoardController {

}
