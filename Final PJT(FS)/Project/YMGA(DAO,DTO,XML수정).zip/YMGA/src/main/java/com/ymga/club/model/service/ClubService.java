package com.ymga.club.model.service;

public interface ClubService {

}
