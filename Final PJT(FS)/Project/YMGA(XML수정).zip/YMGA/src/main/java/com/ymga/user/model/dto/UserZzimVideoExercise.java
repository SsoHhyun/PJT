package com.ymga.user.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserZzimVideoExercise {
	
	private int id;
	private int userSeq;
	private String uri;
	
}
