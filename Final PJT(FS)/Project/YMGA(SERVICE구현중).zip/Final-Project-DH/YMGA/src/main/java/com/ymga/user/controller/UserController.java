package com.ymga.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ymga.user.exception.JoinInputException;
import com.ymga.user.exception.PWIncorrectException;
import com.ymga.user.exception.UserNotFoundException;
import com.ymga.user.model.dto.User;
import com.ymga.user.model.dto.UserDetail;
import com.ymga.user.model.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/join")
	ResponseEntity<Void> join(User user, UserDetail userDetail) {

		try {
			userService.join(user, userDetail);
			return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		} catch (JoinInputException je) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			System.out.println(e);
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping("/login")
	ResponseEntity<User> login(String id, String pw) {

		try {
			return new ResponseEntity<User>(userService.login(id, pw), HttpStatus.OK);
		} catch (UserNotFoundException unfe) {
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		} catch (PWIncorrectException pie) {
			return new ResponseEntity<User>(HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			return new ResponseEntity<User>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

////	@PostMapping("login")
//	public String logian(HttpSession session, String id, String pw) throws Exception {
//		User user = userService.login(id, pw);
//		if(user != null)
//			session.setAttribute("username",user.getUsername() );
//		System.out.println(user);
//		return user!= null?"redirect:/":"redirect:/user/login";
//	}
//	@GetMapping("logout")
//	public String logout(HttpSession session) {
//		session.invalidate();
//		return "redirect:/";
//	}
//	@GetMapping("join")
//	public String joinForm() {
//		return "user/join";
//	}
//	@PostMapping("join")
//	public String join(User user, String msg) {
//		try {
//			userService.join(user, msg);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
////			e.printStackTrace();
////			System.out.println(e.getMessage());
//			return "redirect:/user/join";
//		}
//		return "redirect:/user/login";
//	}

}
