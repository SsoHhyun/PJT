package com.ymga.club.model.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClubBoard {

	private int id;
	private int clubId;
	private String title; 
	private String writer;
	private String content;
	private int viewCnt;
	private Date regDate;
	
}
