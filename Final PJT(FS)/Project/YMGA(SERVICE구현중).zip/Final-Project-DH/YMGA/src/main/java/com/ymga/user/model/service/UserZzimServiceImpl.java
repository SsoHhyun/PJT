package com.ymga.user.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ymga.user.model.dao.UserZzimDao;
import com.ymga.user.model.dto.UserZzim;

@Service
public class UserZzimServiceImpl implements UserZzimService{

	@Autowired
	private UserZzimDao userZzimDao;

	@Override
	public List<UserZzim> selectAllUserZzim(int userSeq) {
		return userZzimDao.selectAllUserZzim(userSeq);
	}

	@Override
	public void registerUserZzim(UserZzim userZzim) {
		userZzimDao.insertUserZzim(userZzim);
	}

	@Override
	public void updateUserZzim(UserZzim userZzim) {
		userZzimDao.updateUserZzim(userZzim);
	}

	@Override
	public void deleteUserZzim(int id) {
		userZzimDao.deleteUserZzim(id);
	}

	@Override
	public UserZzim selectUserZzimById(int id) {
		return userZzimDao.selectUserZzimById(id);
	}

}
