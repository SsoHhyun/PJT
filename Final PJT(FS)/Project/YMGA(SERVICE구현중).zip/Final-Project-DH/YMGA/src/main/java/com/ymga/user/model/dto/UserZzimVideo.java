package com.ymga.user.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserZzimVideo {
	
	// PK
	private int id;
	
	private int userSeq;
	
	// exercise or recipe
	private String type;
	
	private String uri;
	
}
