package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Reply;

public interface ReplyAdDao {
	
	List<Reply> selectAllReplyAd();
	
	void insertReplyAd(Reply Reply);
	
	void updateReplyAd(Reply Reply);
	
	void deleteReplyAd(int id);
	
	Reply selectReplyAdById(int id);

}
