package com.ymga.board.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ymga.board.model.dao.NoticeDao;
import com.ymga.board.model.dto.Notice;

@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private NoticeDao noticeDao;

	@Override
	public List<Notice> selectAllNotice(String boardType) {
		return noticeDao.selectAllNotice(boardType);
	}

	@Override
	public void registerNotice(Notice notice) {
		noticeDao.insertNotice(notice);
	}

	@Override
	public void updateNotice(Notice notice) {
		noticeDao.updateNotice(notice);
	}

	@Override
	public void deleteNotice(int id) {
		noticeDao.deleteNotice(id);
	}

	@Override
	public Notice readNoticeById(int id) {
		Notice notice = noticeDao.selectNoticeById(id);
		notice.setViewCnt(notice.getViewCnt() + 1);
		noticeDao.updateNotice(notice);
		return notice;
	}

	@Override
	public Notice selectNoticeById(int id) {
		return noticeDao.selectNoticeById(id);
	}

}
