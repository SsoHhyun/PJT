package com.ymga.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ymga.board.model.dto.Board;
import com.ymga.board.model.service.BoardService;
import com.ymga.board.model.service.NoticeService;
import com.ymga.board.model.service.ReplyService;

@RestController
@RequestMapping("/board")
public class BoardController {

	@Autowired
	private BoardService boardService;
	@Autowired
	private NoticeService noticeService;
	@Autowired
	private ReplyService replyService;

	@GetMapping("/{type}")
	ResponseEntity<List<Board>> getboardList(@PathVariable("type") String boardType) {

		try {
			return new ResponseEntity<List<Board>>(boardService.selectAllBoard(boardType), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<List<Board>>(HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping("/{type}/{id}")
	ResponseEntity<Board> getboard(@PathVariable("type") String boardType, @PathVariable int id) {

		try {
			return new ResponseEntity<Board>(boardService.selectBoardById(id), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Board>(HttpStatus.BAD_REQUEST);
		}

	}

	@PostMapping("/")
	ResponseEntity<Void> createBoard(Board board) {

		try {
			System.out.println(board);
			boardService.registerBoard(board);
			return new ResponseEntity<Void>(HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}

	}

//	@GetMapping("/free/notice")

//	@GetMapping("/free/reply")

}
