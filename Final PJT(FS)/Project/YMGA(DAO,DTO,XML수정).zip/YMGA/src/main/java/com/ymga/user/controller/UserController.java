package com.ymga.user.controller;

public class UserController {

}
