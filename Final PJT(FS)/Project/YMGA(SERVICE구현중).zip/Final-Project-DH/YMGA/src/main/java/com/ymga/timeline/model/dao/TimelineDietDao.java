package com.ymga.timeline.model.dao;

import java.util.List;

import com.ymga.timeline.model.dto.TimelineDiet;

public interface TimelineDietDao {
	
	List<TimelineDiet> selectAllTimelineDiet();
	
	void insertTimelineDiet(TimelineDiet timelineDiet);
	
	void updateTimelineDiet(TimelineDiet timelineDiet);
	
	void deleteTimelineDiet(int id);
	
	TimelineDiet selectTimelineDietById(int id);

}
