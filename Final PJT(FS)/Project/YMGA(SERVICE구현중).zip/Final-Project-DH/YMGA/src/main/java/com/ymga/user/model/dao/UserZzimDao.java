package com.ymga.user.model.dao;

import java.util.List;

import com.ymga.user.model.dto.UserZzim;

public interface UserZzimDao {

	List<UserZzim> selectAllUserZzim(int userSeq);

	void insertUserZzim (UserZzim userZzim);

	void updateUserZzim(UserZzim userZzim);

	void deleteUserZzim(int id);

	UserZzim selectUserZzimById(int id);

}
