package com.ymga.board.model.service;

import java.util.List;

import com.ymga.board.model.dto.Reply;

public interface ReplyService {
	
	// 댓글 전체 가져오기 (공지 타입 확인)
	List<Reply> selectAllReply(int postId);

	// 댓글 등록하기
	void registerReply(Reply Reply);

	// 댓글 수정하기
	void updateReply(Reply Reply);

	// 댓글 삭제하기
	void deleteReply(int id);

	// 댓글 하나 가져오기
	Reply selectReplyById(int id);
}
