package com.ymga.board.model.service;

import java.util.List;

import com.ymga.board.model.dto.Notice;

public interface NoticeService {

	// 공지 전체 가져오기 (공지 타입 확인)
	List<Notice> selectAllNotice(String boardType);

	// 공지에 글 등록하기
	void registerNotice(Notice notice);

	// 공지에 글 수정하기
	void updateNotice(Notice notice);

	// 공지에 글 삭제하기
	void deleteNotice(int id);

	// 글 하나 읽기(조회수 증가)
	Notice readNoticeById(int id);

	// 글 하나 가져오기
	Notice selectNoticeById(int id);

}
