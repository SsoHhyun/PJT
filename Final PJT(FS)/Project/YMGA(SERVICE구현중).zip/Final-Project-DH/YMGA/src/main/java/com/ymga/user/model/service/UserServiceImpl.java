package com.ymga.user.model.service;

import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ymga.user.exception.JoinInputException;
import com.ymga.user.exception.PWIncorrectException;
import com.ymga.user.exception.UserNotFoundException;
import com.ymga.user.model.dao.UserDao;
import com.ymga.user.model.dao.UserDetailDao;
import com.ymga.user.model.dao.UserZzimDao;
import com.ymga.user.model.dao.UserZzimVideoDao;
import com.ymga.user.model.dto.User;
import com.ymga.user.model.dto.UserDetail;
import com.ymga.user.util.SHA256;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	@Autowired
	private UserDetailDao userDetailDao;

	@Transactional
	@Override
	public void join(User user, UserDetail userDetail) throws JoinInputException, NoSuchAlgorithmException {

		if (user.getId() == null || user.getPw() == null || user.getNickname() == null || user.getEmail() == null) {
			throw new JoinInputException();
		}

		/// pw 해쉬 처리
		user.setPw(new SHA256().getHash(user.getPw()));

		userDao.insertUser(user);

		if (userDetail.getHeight() != 0 || userDetail.getWeight() != 0 || userDetail.getGoal() != null
				|| userDetail.getProfileImg() != null) {

			// DB로부터 seq값 받아서 setUserSeq
			userDetail.setUserSeq(userDao.selectUserById(user.getId()).getSeq());

			userDetailDao.insertUserDetail(userDetail);

		}

	}

	@Override
	public User login(String id, String pw)
			throws UserNotFoundException, NoSuchAlgorithmException, PWIncorrectException {

		User user = userDao.selectUserById(id);

		if (user == null)
			throw new UserNotFoundException();

		if (!user.getPw().equals(new SHA256().getHash(pw)))
			throw new PWIncorrectException();

		return user;
		
	}

}
