package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Reply;

public interface ReplyInformDao {
	
	List<Reply> selectAllReplyInform();
	
	void insertReplyInform(Reply Reply);
	
	void updateReplyInform(Reply Reply);
	
	void deleteReplyInform(int id);
	
	Reply selectReplyInformById(int id);

}
