package com.ymga.club.model.dao;

import java.util.HashMap;
import java.util.List;

import com.ymga.club.model.dto.Club;

public interface ClubDao {

	List<Club> selectAllClub(HashMap<String, String> params);

	void insertClub(Club club);

	void updateClub(Club club);

	void deleteClub(int id);

	Club selectClubById(int id);

}
