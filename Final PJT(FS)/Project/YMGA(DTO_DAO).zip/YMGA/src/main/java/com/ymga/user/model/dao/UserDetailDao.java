package com.ymga.user.model.dao;

import com.ymga.user.model.dto.UserDetail;

public interface UserDetailDao {
	
	void insertUserDetail(UserDetail userDetail);
	
	void updateUserDetail(UserDetail userDetail);
	
	void deleteUserDetail(int userSeq);
	
	UserDetail selectUserDetailById(String id);
}
