package com.ymga.timeline.model.service;

public interface TimelineService {

}
