package com.ymga.user.model.dao;

import java.util.List;

import com.ymga.user.model.dto.UserZzimVideoDiet;

public interface UserZzimVideoDietDao {
	
	List<UserZzimVideoDiet> selectAllUserZzimVideoDiet(int userSeq);

	void insertUserZzimVideoDiet(UserZzimVideoDiet userZzimVideo);
	
	void updateUserZzimVideo(UserZzimVideoDiet userZzimVideo);
	
	void deleteUserZzimVideo(int id);
	
	UserZzimVideoDiet selectUserZzimVideoById(int id);
	
}
