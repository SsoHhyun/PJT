package com.ymga.user.model.dao;

import java.util.List;

import com.ymga.user.model.dto.UserZzimVideoExercise;

public interface UserZzimVideoExerciseDao {
	
	List<UserZzimVideoExercise> selectAllUserZzimVideoExercise(int userSeq);

	void insertUserZzimVideo(UserZzimVideoExercise userZzimVideo);
	
	void updateUserZzimVideo(UserZzimVideoExercise userZzimVideo);
	
	void deleteUserZzimVideo(int id);
	
	UserZzimVideoExercise selectUserZzimVideoById(int id);
	
}
