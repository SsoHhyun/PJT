package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Reply;

public interface ReplyDao {
	
	List<Reply> selectAllReply(int postId);
	
	void insertReply(Reply Reply);
	
	void updateReply(Reply Reply);
	
	void deleteReply(int id);
	
	Reply selectReplyById(int id);

}
