package com.ymga.user.exception;

public class JoinInputException extends Exception {
	public JoinInputException() {
		super("필수정보를 입력하세요.");
	}
}
