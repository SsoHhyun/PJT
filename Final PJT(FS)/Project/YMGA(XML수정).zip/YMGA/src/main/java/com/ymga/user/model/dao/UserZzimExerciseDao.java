package com.ymga.user.model.dao;

import java.util.List;

import com.ymga.user.model.dto.UserZzimExercise;

public interface UserZzimExerciseDao {
	
	List<UserZzimExercise> selectAllUserZzimExercise(int userSeq);
	
	void insertUserZzimExercise (UserZzimExercise userZzimExercise);
	
	void updateUserZzimExercise(UserZzimExercise userZzimExercise);
	
	void deleteUserZzimExercise(int id);
	
	UserZzimExercise selectUserZzimExerciseById(int id);
	
}
