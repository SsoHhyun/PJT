package com.ymga;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YmgaApplication {

	public static void main(String[] args) {
		SpringApplication.run(YmgaApplication.class, args);
	}

}
