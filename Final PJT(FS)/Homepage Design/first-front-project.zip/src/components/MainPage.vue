<template>
  <div>
    <b-carousel
      id="carousel-no-animation"
      style="text-shadow: 0px 0px 2px #000; margin: 100px"
      no-animation
      indicators
      img-width="1024"
      img-height="100"
    >
      <b-carousel-slide
        caption="First Slide"
        img-src="https://picsum.photos/1024/480/?image=10"
      ></b-carousel-slide>
      <b-carousel-slide
        caption="Second Slide"
        img-src="https://picsum.photos/1024/480/?image=12"
      ></b-carousel-slide>
      <b-carousel-slide
        caption="Third Slide"
        img-src="https://picsum.photos/1024/480/?image=22"
      ></b-carousel-slide>
      <b-carousel-slide
        caption="Fourth Slide"
        img-src="https://picsum.photos/1024/480/?image=23"
      ></b-carousel-slide>
    </b-carousel>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>