package com.ymga.user.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDetail {
	private int userSeq;
	private int height;
	private int weight;
	private String goal;
	private String profileImg;

}
