package com.ymga.configuration;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan(basePackages = "com.ymga.*.model.dao") // 별표 안먹히면 배열로
public class DBConfig {}
