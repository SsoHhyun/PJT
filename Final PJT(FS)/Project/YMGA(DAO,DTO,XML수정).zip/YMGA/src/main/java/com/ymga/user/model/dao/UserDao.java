package com.ymga.user.model.dao;

import com.ymga.user.model.dto.User;

public interface UserDao {
	
	void insertUser(User user);
	
	void updateUser(User user);
	
	void deleteUser(int seq);
	
	User selectUserById(String id);
	
}
