package com.ymga.board.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ymga.board.model.dao.ReplyDao;
import com.ymga.board.model.dto.Reply;

@Service
public class ReplyServiceImpl implements ReplyService {

	@Autowired
	private ReplyDao replyDao;

	@Override
	public List<Reply> selectAllReply(int postId) {
		return replyDao.selectAllReply(postId);
	}

	@Override
	public void registerReply(Reply Reply) {
		replyDao.insertReply(Reply);
	}

	@Override
	public void updateReply(Reply Reply) {
		replyDao.updateReply(Reply);
	}

	@Override
	public void deleteReply(int id) {
		replyDao.deleteReply(id);
	}

	@Override
	public Reply selectReplyById(int id) {
		return replyDao.selectReplyById(id);
	}

}
