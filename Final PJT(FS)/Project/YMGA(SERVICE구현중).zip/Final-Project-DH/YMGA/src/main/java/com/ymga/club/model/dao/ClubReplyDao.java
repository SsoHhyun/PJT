package com.ymga.club.model.dao;

import java.util.List;

import com.ymga.club.model.dto.ClubReply;

public interface ClubReplyDao {

	List<ClubReply> selectAllClubReply(int postId);

	void insertClubReply(ClubReply clubReply);

	void updateClubReply(ClubReply clubReply);

	void deleteClubReply(int id);

	ClubReply selectClubReplyById(int id);

}
