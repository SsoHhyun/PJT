package com.ymga.user.model.service;

import java.util.List;

import com.ymga.user.model.dto.UserZzim;

public interface UserZzimService {

	// 유저의 전체 찜목록
	List<UserZzim> selectAllUserZzim(int userSeq);

	// 찜 등록하기
	void registerUserZzim(UserZzim userZzim);

	// 찜 수정하기
	void updateUserZzim(UserZzim userZzim);

	// 찜 삭제하기
	void deleteUserZzim(int id);

	// 찜 하나 읽기
	UserZzim selectUserZzimById(int id);

}
