package com.ymga.club.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClubMember {
	
	private int clubId;
	private int userSeq;
	private String rank;
	
}
