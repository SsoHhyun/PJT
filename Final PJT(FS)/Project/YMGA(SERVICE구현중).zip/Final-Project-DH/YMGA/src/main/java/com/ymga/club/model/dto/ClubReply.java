package com.ymga.club.model.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClubReply {

	private int id;
	private int postId;
	private String writer;
	private String content;
	private Date regDate;

}
