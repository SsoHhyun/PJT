<template>
  <div>
    <Header />
    <MainPage />
    <MainPage />
    <MainPage />
  </div>
</template>

<script>
import Header from "@/components/common/header.vue";
import MainPage from "@/components/MainPage.vue";
export default {
  name: "HomeView",
  components: {
    Header,
    MainPage,
  },
};
</script>
