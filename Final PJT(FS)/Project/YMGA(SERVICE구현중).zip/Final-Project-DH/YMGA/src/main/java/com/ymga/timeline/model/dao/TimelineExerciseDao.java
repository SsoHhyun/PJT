package com.ymga.timeline.model.dao;

import java.util.List;

import com.ymga.timeline.model.dto.TimelineExercise;

public interface TimelineExerciseDao {

	List<TimelineExercise> selectAllTimelineExercise();

	void insertTimelineExercise(TimelineExercise timelineExercise);

	void updateTimelineExercise(TimelineExercise timelineExercise);

	void deleteTimelineExercise(int id);

	TimelineExercise selectTimelineExerciseById(int id);

}
