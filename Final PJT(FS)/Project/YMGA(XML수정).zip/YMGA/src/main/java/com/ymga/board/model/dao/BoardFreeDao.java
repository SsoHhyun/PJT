package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Board;

public interface BoardFreeDao {
	
	List<Board> selectAllBoardFree();
	
	void insertBoardFree(Board board);
	
	void updateBoardFree(Board board);
	
	void deleteBoardFree(int id);
	
	Board selectBoardFreeById(int id);

}
