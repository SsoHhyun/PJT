package com.ymga.board.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reply {

	private int id;
	private String boardType;
	private int postId;
	private String writer;
	private String content;
	private String regDate;
	
}
