package com.ymga.user.model.service;

import java.util.List;

import com.ymga.user.model.dto.UserZzimVideo;

public interface UserZzimVideoService {

	// 유저의 전체 찜(영상)목록
	List<UserZzimVideo> selectAllUserZzimVideo(int userSeq);

	// 찜(영상) 등록하기
	void registerUserZzimVideo(UserZzimVideo userZzimVideo);

	// 찜(영상) 수정하기
	void updateUserZzimVideo(UserZzimVideo userZzimVideo);

	// 찜(영상) 삭제하기
	void deleteUserZzimVideo(int id);

	// 찜(영상) 하나 읽기
	UserZzimVideo selectUserZzimVideoById(int id);

}
