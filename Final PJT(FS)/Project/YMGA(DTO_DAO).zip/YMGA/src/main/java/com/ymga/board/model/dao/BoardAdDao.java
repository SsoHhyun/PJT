package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Board;

public interface BoardAdDao {
	
	List<Board> selectAllBoardAd();
	
	void insertBoardAd(Board board);
	
	void updateBoardAd(Board board);
	
	void deleteBoardAd(int id);
	
	Board selectBoardAdById(int id);

}
