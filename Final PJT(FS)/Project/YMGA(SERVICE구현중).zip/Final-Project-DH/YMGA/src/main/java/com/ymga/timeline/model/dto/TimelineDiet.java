package com.ymga.timeline.model.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TimelineDiet {

	private int id;
	private int userSeq;
	private Date date;
	private String type;
	private String amount;
	private boolean publicity;

}
