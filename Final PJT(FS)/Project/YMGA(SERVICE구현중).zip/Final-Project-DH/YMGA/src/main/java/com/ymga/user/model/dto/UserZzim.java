package com.ymga.user.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserZzim {
	
	// primary key
	private int id;
	
	private int userSeq;
	
	private String type;
	
	// api로 생성된 아이디
	private int zzimId;
	
}
