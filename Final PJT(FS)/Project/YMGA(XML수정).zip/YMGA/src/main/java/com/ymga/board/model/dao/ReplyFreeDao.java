package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Reply;

public interface ReplyFreeDao {
	
	List<Reply> selectAllReplyFree();
	
	void insertReplyFree(Reply Reply);
	
	void updateReplyFree(Reply Reply);
	
	void deleteReplyFree(int id);
	
	Reply selectReplyFreeById(int id);

}
