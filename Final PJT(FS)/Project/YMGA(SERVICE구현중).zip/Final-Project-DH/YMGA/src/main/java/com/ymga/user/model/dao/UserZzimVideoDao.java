package com.ymga.user.model.dao;

import java.util.List;

import com.ymga.user.model.dto.UserZzimVideo;

public interface UserZzimVideoDao {
	
	List<UserZzimVideo> selectAllUserZzimVideo(int userSeq);

	void insertUserZzimVideo(UserZzimVideo userZzimVideo);
	
	void updateUserZzimVideo(UserZzimVideo userZzimVideo);
	
	void deleteUserZzimVideo(int id);
	
	UserZzimVideo selectUserZzimVideoById(int id);
	
}
