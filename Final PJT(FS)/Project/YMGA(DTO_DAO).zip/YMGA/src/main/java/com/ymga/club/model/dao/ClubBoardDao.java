package com.ymga.club.model.dao;

import java.util.List;

import com.ymga.club.model.dto.ClubBoard;

public interface ClubBoardDao {

	List<ClubBoard> selectAllClubBoard(int clubId);

	void insertClubBoard(ClubBoard clubBoard);

	void updateClubBoard(ClubBoard clubBoard);

	void deleteClubBoard(int id);

	ClubBoard selectClubBoardById(int id);

}
