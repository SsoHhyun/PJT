package com.ymga.user.model.dao;

import java.util.List;

import com.ymga.user.model.dto.UserZzimDiet;

public interface UserZzimDietDao {
	
	List<UserZzimDiet> selectAllUserZzimDiet(int userSeq);

	void insertUserZzimDiet(UserZzimDiet userZzimDiet);
	
	void updateUserZzimDiet(UserZzimDiet userZzimDiet);
	
	void deleteUserZzimDiet(int id);
	
	UserZzimDiet selectUserZzimDietById(int id);
	
	
	
}
