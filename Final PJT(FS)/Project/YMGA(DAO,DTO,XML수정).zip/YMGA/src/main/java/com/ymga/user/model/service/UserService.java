package com.ymga.user.model.service;

public interface UserService {

}
