package com.ymga.user.model.service;

import java.security.NoSuchAlgorithmException;

import com.ymga.user.exception.JoinInputException;
import com.ymga.user.exception.PWIncorrectException;
import com.ymga.user.exception.UserNotFoundException;
import com.ymga.user.model.dto.User;
import com.ymga.user.model.dto.UserDetail;

public interface UserService {

	void join(User user, UserDetail userDetail) throws JoinInputException, NoSuchAlgorithmException;

	User login(String id, String pw) throws UserNotFoundException, NoSuchAlgorithmException, PWIncorrectException;
	
	
	
}
