package com.ymga.club.model.dao;

import java.util.List;

import com.ymga.club.model.dto.ClubMember;

public interface ClubMemberDao {
	
	// 클럽 회원 전체 목록
	List<ClubMember> selectAllClubMember(int clubId);

	// 클럽 회원 추가하기
	void insertClubMember(ClubMember clubMember);
	
	// 클럽 회원 수정하기
	void updateClubMember(ClubMember clubMember);	
	
	//클럽 회원 삭제하기
	void deleteClubMember(int id);
	
	// 클럽 회원 한 명 고르기
	ClubMember selectClubMemberById(int id);

}
