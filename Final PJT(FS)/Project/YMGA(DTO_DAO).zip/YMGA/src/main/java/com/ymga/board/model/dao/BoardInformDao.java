package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Board;

public interface BoardInformDao {
	
	List<Board> selectAllBoardInform();
	
	void insertBoardInform(Board board);
	
	void updateBoardInform(Board board);
	
	void deleteBoardInform(int id);
	
	Board selectBoardInformById(int id);

}
