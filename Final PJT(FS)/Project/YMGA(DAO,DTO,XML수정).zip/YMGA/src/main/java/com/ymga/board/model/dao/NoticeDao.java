package com.ymga.board.model.dao;

import java.util.List;

import com.ymga.board.model.dto.Notice;

public interface NoticeDao {
	
	List<Notice> selectAllNotice(String boardType);
	
	void insertNotice(Notice notice);
	
	void updateNotice(Notice notice);
	
	void deleteNotice(int id);
	
	Notice selectNoticeById(int id);

}
