package com.ymga.club.model.dao;

import java.util.List;

import com.ymga.club.model.dto.ClubNotice;

public interface ClubNoticeDao {

	List<ClubNotice> selectAllClubNotice(int clubId);

	void insertClubNotice(ClubNotice clubNotice);

	void updateClubNotice(ClubNotice clubNotice);

	void deleteClubNotice(int id);

	ClubNotice selectClubNoticeById(int id);

}
